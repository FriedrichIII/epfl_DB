<?php
	include '../includes/header.php';
?>
<h3>Insert athlete:</h3>
<form action="execute.php" method="get">
<p>
name: <input type="text" name="name_field">
</p>
<input type="hidden" name="entry_type" value="athlete">
<input type="submit" name="action" value="Insert">
<input type="submit" name="action" value="Delete">
</form>
<?php include '../includes/footer.php'; ?>
