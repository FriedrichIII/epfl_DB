<?php include '../includes/header.php'; ?>
<h3>Insert/Delete...</h3>
<ol>
<li><a href="athleteForm.php"       >athlete</a></li>
<li><a href="cityForm.php"          >city</a></li>
<li><a href="countryForm.php"       >country</a></li>
<li><a href="disciplineForm.php"    >discipline</a></li>
<li><a href="eventForm.php"         >event</a></li>
<li><a href="sportForm.php"         >sport</a></li>
<li><a href="teamForm.php"          >team</a></li>
</ol>
<?php include '../includes/footer.php'; ?>