<?php include '../includes/header.php'; ?>
<h3>Insert sport:</h3>
<form action="execute.php" method="get">
<p>
name: <input type="text" name="name_field"><br />
</p>
<input type="hidden" name="entry_type" value="sport">
<input type="submit" name="action" value="Insert">
<input type="submit" name="action" value="Delete">
</form>
<?php include '../includes/footer.php'; ?>
