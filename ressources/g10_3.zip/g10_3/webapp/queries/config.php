<?php
	// This file should be in a secure place but it is not for simplicity as this
	// is only a dummy site.

	$DATABASE_HOST = 'ec2-23-21-211-172.compute-1.amazonaws.com';
	$DATABASE_NAME = 'olympics';
	$DATABASE_LOGIN = 'g10';
	$DATABASE_PASSWORD = 'g10';
	// NB: Database type is not an option since our queries use mysql only function CONCAT.
?>