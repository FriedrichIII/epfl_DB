<?php
	// This file should be in a secure place but it is not for simplicity as this
	// is only a dummy site.

	$DATABASE_HOST = 'localhost';
	$DATABASE_NAME = 'olympics';
	$DATABASE_LOGIN = 'root';
	$DATABASE_PASSWORD = '';
	// NB: Database type is not an option since our queries use mysql only function CONCAT.
?>