<h1>Olympic stats</h1>

<form action="queries/search.php" method="get">
<input type="text" name="search_field">
<input type="submit" value="Search">
</form>

<h3>Special queries:</h3>
<ol>
<li><a href="queries/multiseasonMedalists.php"               >multi-season medalists</a></li>
<li><a href="queries/goldMedalists.php"                      >gold medalists</a></li>
<li><a href="queries/firstMedalPlacesByCountry.php"          >first medal places by country</a></li>
<li><a href="queries/countriesWithMostMedalsBySeason.php"    >countries with most medals by season</a></li>
<li><a href="queries/multiHostCities.php"                    >multi-host cities</a></li>
<li><a href="queries/multinationalAthletes.php"              >multinational athletes</a></li>
<li><a href="queries/countriesWithMostParticipantsByGame.php">countries with most participants by game</a></li>
<li><a href="queries/medallessCountries.php"                 >medalless countries</a></li>
</ol>